package br.senai.sp.jandira.mobile_aquarela.model

data class Result(
    val Cadastro: List<Cadastro>
)

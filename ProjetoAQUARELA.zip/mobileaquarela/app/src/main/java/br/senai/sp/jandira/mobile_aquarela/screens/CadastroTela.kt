package br.senai.sp.jandira.mobile_aquarela.screens

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.GMobiledata
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.senai.sp.jandira.mobile_aquarela.model.Cadastro
import br.senai.sp.jandira.mobile_aquarela.model.Result
import br.senai.sp.jandira.mobile_aquarela.service.RetrofitFactory
import br.senai.sp.jandira.mobile_aquarela.R
import br.senai.sp.jandira.mobile_aquarela.R.drawable
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@Composable
fun CadastroTela() {
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xffE2E8EB)) {
        // Usando um Box para sobrepor a imagem
        Box(modifier = Modifier.fillMaxSize()) {
            // Imagem de fundo


            // Conteúdo da tela
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 150.dp), // Adiciona padding no topo para evitar sobreposição
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceEvenly
            ) {
                var emailState by remember { mutableStateOf("") }
                var senhaState by remember { mutableStateOf("") }
                var rememberMeState by remember { mutableStateOf(false) }

                Row(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "icon",
                        tint = Color.White,
                        modifier = Modifier
                            .background(color = Color(0xff3E7D8D), shape = CircleShape)
                            .padding(4.dp)
                    )
                }

                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Bem-Vindo!",
                        fontSize = 32.sp,
                        color = Color(0xff3E7D8D),
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Faça login na sua conta",
                        fontSize = 14.sp,
                        color = Color(0xff5DA5B7)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Top
                ) {
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 30.dp),
                        value = emailState,
                        onValueChange = { emailState = it },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xffB8CED4),
                            unfocusedBorderColor = Color.Transparent,
                            focusedContainerColor = Color(0xffB8CED4)
                        ),
                        label = { Text(text = "Email") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Email, contentDescription = " ")
                        },
                        shape = RoundedCornerShape(8.dp)
                    )
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 30.dp),
                        value = senhaState,
                        onValueChange = { senhaState = it },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xffB8CED4),
                            unfocusedBorderColor = Color.Transparent,
                            focusedContainerColor = Color(0xffB8CED4)
                        ),
                        label = { Text(text = "Senha") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = " ")
                        },
                        shape = RoundedCornerShape(8.dp)
                    )

                    // Lembre-se de mim
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier
                                .clickable { rememberMeState = !rememberMeState }
                                .padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.Checkbox(
                                checked = rememberMeState,
                                modifier = Modifier.padding(0.dp), // Removendo o padding para aproximar
                                onCheckedChange = { rememberMeState = it }
                            )
                            Text(
                                text = "Lembre-se de mim",
                                color = Color(0xff5DA5B7),
                                fontSize = 14.sp,
                                modifier = Modifier.padding(start = 0.dp) // Reduzindo o padding para aproximar
                            )
                        }
                        Text(
                            text = "Esqueceu a senha?",
                            color = Color(0xff3E7D8D),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 30.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        val callUsuarios = RetrofitFactory().pegarCadastroService().inserirUsuarios(
                            cadastros = Cadastro(
                                email = emailState,
                                senha = senhaState,
                                disponibilidade = null,
                                user_stats = true
                            )
                        )
                        callUsuarios.enqueue(object : Callback<Result> {
                            override fun onResponse(call: Call<Result>, response: Response<Result>) {
                                Log.i("foi", response.body().toString())
                            }

                            override fun onFailure(call: Call<Result>, t: Throwable) {
                                Log.i("falhou", t.toString())
                            }
                        })
                    },
                    modifier = Modifier
                        .width(270.dp)
                        .height(50.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xff5DA5B7) // Cor de fundo do botão
                    )
                ) {
                    Text(text = "Login", fontSize = 20.sp, color = Color.White)
                }

                // Centralizando o texto "ou"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center // Centraliza horizontalmente
                ) {
                    HorizontalDivider(
                        modifier = Modifier
                            .height(1.dp) // Altura do divisor
                            .width(120.dp) // Define a largura do divisor à esquerda
                    )
                    Text(
                        text = "ou",
                        modifier = Modifier.padding(horizontal = 8.dp), // Espaço ao redor do texto
                        color = Color(0xff3E7D8D),
                        fontWeight = FontWeight.Bold
                    )
                    HorizontalDivider(
                        modifier = Modifier
                            .height(1.dp) // Altura do divisor
                            .width(120.dp) // Define a largura do divisor à direita
                    )
                }

                Row(
                    modifier = Modifier
                        .background(color = Color(0xff3E7D8D), shape = RoundedCornerShape(20.dp))
                        .width(270.dp)
                        .height(35.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.GMobiledata, contentDescription = " ", tint = Color.White)
                    Text(text = "Cadastre com o google", color = Color.White)
                }
            }
        }
    }
}

@Composable
@Preview(showSystemUi = true, showBackground = true)
fun CadastroTelaPreview() {
    CadastroTela()
}
